package com.agenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaVisitasApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgendaVisitasApplication.class, args);
    }
}
